public interface TicketComponent {
    void display();

    void initialize();
}
