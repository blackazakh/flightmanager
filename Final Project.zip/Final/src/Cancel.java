import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class Cancel extends JFrame {

    private JTextField textFieldName, textFieldPhNo, textFieldFlightCode;

    public static void main(String[] args) {
        new Cancel().setVisible(true);
    }

    public Cancel() {
        setTitle("CANCEL RESERVATION");
        getContentPane().setBackground(Color.WHITE);
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setSize(778, 486);
        getContentPane().setLayout(null);

        JLabel lblCancelReservation = new JLabel("Cancel Reservation");
        lblCancelReservation.setForeground(Color.BLUE);
        lblCancelReservation.setFont(new Font("Tahoma", Font.PLAIN, 31));
        lblCancelReservation.setBounds(250, 24, 400, 35);
        add(lblCancelReservation);

        JLabel lblName = new JLabel("Name:");
        lblName.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lblName.setBounds(60, 120, 150, 27);
        add(lblName);


        JLabel lblFlightCode = new JLabel("Flight Code:");
        lblFlightCode.setFont(new Font("Tahoma", Font.PLAIN, 17));
        lblFlightCode.setBounds(60, 220, 150, 27);
        add(lblFlightCode);

        textFieldName = new JTextField();
        textFieldName.setBounds(200, 120, 150, 27);
        add(textFieldName);


        textFieldFlightCode = new JTextField();
        textFieldFlightCode.setBounds(200, 220, 150, 27);
        add(textFieldFlightCode);

        JButton btnCancel = new JButton("CANCEL");
        btnCancel.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnCancel.setBackground(Color.BLACK);
        btnCancel.setForeground(Color.WHITE);
        btnCancel.setBounds(200, 300, 150, 30);
        add(btnCancel);

        btnCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                String name = textFieldName.getText();
                String flightCode = textFieldFlightCode.getText();

                if (isPassengerInFlight(name, flightCode)) {
                    cancelReservation(name, flightCode);
                    addTicketToFlight(flightCode);
                    JOptionPane.showMessageDialog(null, "Reservation canceled successfully!");
                    setVisible(false);
                } else {
                    JOptionPane.showMessageDialog(null, "Passenger not found for the specified flight!");
                }
            }
        });

        setSize(900, 600);
        setVisible(true);
        setLocation(400, 200);
    }

    private boolean isPassengerInFlight(String name,  String flightCode) {
        try {
            conn c = new conn();
            String query = "SELECT * FROM passenger WHERE name = '" + name  + "' AND fl_code = '" + flightCode + "'";
            ResultSet rs = c.s.executeQuery(query);
            return rs.next();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    private void cancelReservation(String name, String flightCode) {
        try {
            conn c = new conn();
            String deleteQuery = "DELETE FROM passenger WHERE name = '" + name + "' AND fl_code = '" + flightCode + "'";
            c.s.executeUpdate(deleteQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    private void addTicketToFlight(String flightCode) {
        try {
            conn c = new conn();
            String updateQuery = "UPDATE flights_table SET available_tickets_quantity = available_tickets_quantity + 1 WHERE flight_number = '" + flightCode + "'";
            c.s.executeUpdate(updateQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
