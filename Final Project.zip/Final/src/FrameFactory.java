import javax.swing.*;
import java.awt.*;

public interface FrameFactory {
    AbstractFrame createFrame();
}
abstract class AbstractFrame extends JFrame {
    public abstract void initialize();

    public AbstractFrame(String title) {
        super(title);
    }
}
class MainFrameFactory implements FrameFactory {
    @Override
    public AbstractFrame createFrame() {
        return new Main("AIRLINE RESERVATION MANAGEMENT SYSTEM", "Welcome To Our Flight Reservation System", Color.BLUE,new ImageIcon("C:\\Users\\bbora\\IdeaProjects\\Final\\src\\image\\istockphoto-155439315-612x612.jpg"), 500, 500);
    }
}
class TicketFrameFactory implements FrameFactory {
    @Override
    public AbstractFrame createFrame() {
        return new Ticket("TICKET") {
            @Override
            public void actionPerformed() {
            }
        };
    }
}
