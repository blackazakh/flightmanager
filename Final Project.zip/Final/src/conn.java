import java.sql.*;

public class conn {
    private static Connection c;
    public static Statement s;

    public conn() {
        try {
            Class.forName("org.postgresql.Driver");
            c = DriverManager.getConnection("jdbc:postgresql://localhost:1111/soft", "postgres", "Ba87475569215");
            s = c.createStatement();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    public static Statement getStatement() {
        if (c == null || s == null) {
            new conn();
        }
        return s;
    }
}
