import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TicketDecorator extends AbstractFrame implements TicketComponent {
    private final TicketComponent ticketComponent;

    public TicketDecorator(String title, TicketComponent ticketComponent) {
        super(title);
        this.ticketComponent = ticketComponent;
        initialize();
    }

    @Override
    public void initialize() {
        // Delegate the initialization to the original TicketComponent
        ticketComponent.initialize();

        // Decorate the Buy Ticket button with an additional action
        JButton decoratedBuyTicketButton = new JButton("Buy Ticket (with Total Price)");
        decoratedBuyTicketButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
        decoratedBuyTicketButton.setBounds(350, 550, 250, 30);
        add(decoratedBuyTicketButton);

        decoratedBuyTicketButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                openAddCustomerMenuWithTotalPrice();
            }
        });
        JMenuItem totalFlightsMenuItem = new JMenuItem("Show Total Flights and Available Tickets");
        totalFlightsMenuItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showTotalFlightsAndAvailableTickets();
            }
        });
        JMenu airlineSystemMenu = findMenu("AIRLINE SYSTEM");
        if (airlineSystemMenu != null) {
            airlineSystemMenu.add(totalFlightsMenuItem);
        }

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void openAddCustomerMenuWithTotalPrice() {
        displayTotalPrice();
        new AddCustomer();
        setVisible(false);
    }

    private void displayTotalPrice() {
        System.out.println("Calculating and Displaying Total Price of Available Tickets");
    }

    private void showTotalFlightsAndAvailableTickets() {
        System.out.println("Showing Total Flights and Available Tickets");
    }
    private JMenu findMenu(String menuName) {
        JMenuBar menuBar = getJMenuBar();
        for (int i = 0; i < menuBar.getMenuCount(); i++) {
            JMenu menu = menuBar.getMenu(i);
            if (menu != null && menu.getText().equals(menuName)) {
                return menu;
            }
        }
        return null;
    }

    @Override
    public void display() {
        ticketComponent.display();
    }
}
