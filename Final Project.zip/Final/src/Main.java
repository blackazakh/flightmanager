import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Main extends AbstractFrame {
    public Main(String title, String welcomeMessage, Color welcomeMessageColor, ImageIcon backgroundImage, int width, int height) {
        super(title);
        initialize(welcomeMessage, welcomeMessageColor, backgroundImage, width, height);
    }

    public static MainBuilder builder() {
        return new MainBuilder();
    }

    public static void main(String[] args) {
        Main mainFrame = Main.builder()
                .setTitle("AIRLINE RESERVATION MANAGEMENT SYSTEM")
                .setWelcomeMessage("Welcome To Our Flight Reservation System")
                .setWelcomeMessageColor(Color.BLUE)
                .setBackgroundImage(new ImageIcon("C:\\Users\\bbora\\IdeaProjects\\Final\\src\\image\\istockphoto-155439315-612x612.jpg"))
                .setSize(500, 500)
                .build();

        mainFrame.setVisible(true);
    }

    public void initialize(String welcomeMessage, Color welcomeMessageColor, ImageIcon backgroundImage, int width, int height) {
        setForeground(Color.CYAN);
        setLayout(null);

        JLabel backgroundLabel = new JLabel(backgroundImage);
        backgroundLabel.setBounds(0, 0, backgroundImage.getIconWidth(), backgroundImage.getIconHeight());
        setContentPane(backgroundLabel);

        JLabel airlineManagementSystem = new JLabel(welcomeMessage);
        airlineManagementSystem.setForeground(welcomeMessageColor);
        airlineManagementSystem.setFont(new Font("Tahoma", Font.PLAIN, 18));
        airlineManagementSystem.setBounds(50, 10, 500, 25);
        backgroundLabel.add(airlineManagementSystem);

        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        JMenu airlineSystem = new JMenu("AIRLINE SYSTEM");
        airlineSystem.setForeground(Color.BLUE);
        menuBar.add(airlineSystem);

        JMenuItem ticketItem = new JMenuItem("TICKET");
        ticketItem.setForeground(Color.RED);
        airlineSystem.add(ticketItem);

        JMenuItem flightDetailsItem = new JMenuItem("FLIGHT INFO");
        airlineSystem.add(flightDetailsItem);
        flightDetailsItem.setForeground(Color.GREEN);

        JMenuItem cancellationItem = new JMenuItem("CANCELLATION");
        airlineSystem.add(cancellationItem);
        cancellationItem.setForeground(Color.BLUE);

        flightDetailsItem.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new FlightInfo();
            }
        });

        ticketItem.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                new Ticket("TICKET") {
                    @Override
                    public void actionPerformed() {
                        // Implement if needed
                    }
                };
            }
        });

        cancellationItem.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new Cancel();
            }
        });

        setSize(width, height);
        setVisible(true);
    }

    @Override
    public void initialize() {

    }
}
