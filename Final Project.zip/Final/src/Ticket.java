import net.proteanit.sql.DbUtils;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.*;

public abstract class Ticket extends AbstractFrame implements TicketComponent{

    private JTable table;
    private JButton buyTicketButton;
        public static void main(String[] args) {
            FrameFactory factory = new TicketFrameFactory();
            AbstractFrame ticketFrame = factory.createFrame();
            ticketFrame.setVisible(true);
        }

        public Ticket(String title) {
            super(title);
            initialize();
        }

    public void initialize() {
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        JLabel ticketLabel = new JLabel("Available Tickets");
        ticketLabel.setForeground(new Color(100, 149, 237));
        ticketLabel.setFont(new Font("Tahoma", Font.PLAIN, 31));
        ticketLabel.setBounds(350, 27, 250, 35);
        add(ticketLabel);

        buyTicketButton = new JButton("Buy Ticket");
        buyTicketButton.setFont(new Font("Tahoma", Font.PLAIN, 17));
        buyTicketButton.setBounds(350, 500, 150, 30);
        add(buyTicketButton);

        buyTicketButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {
                openAddCustomerMenu();
            }
        });

        table = new JTable();
        table.setBackground(Color.WHITE);
        table.setBounds(23, 100, 800, 350);

        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(23, 100, 800, 350);
        pane.setBackground(Color.WHITE);
        add(pane);
        display();
        setLocationRelativeTo(null);
        setVisible(true);
    }


    private void openAddCustomerMenu() {
        new AddCustomer();
        setVisible(false);
    }

    @Override
    public void display() {
        ResultSet resultSet = null;

        try {
            conn c = new conn();
            String query = "SELECT flight_number, source, destination, available_tickets_quantity, price, seat_class FROM flights_table";
            resultSet = c.s.executeQuery(query);

            table.setModel(DbUtils.resultSetToTableModel(resultSet));

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public abstract void actionPerformed();
}
