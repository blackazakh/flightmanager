import javax.swing.*;
import java.awt.*;

public class MainBuilder {
    private String title;
    private String welcomeMessage;
    private Color welcomeMessageColor;
    private ImageIcon backgroundImage;
    private int width;
    private int height;

    public MainBuilder setTitle(String title) {
        this.title = title;
        return this;
    }

    public MainBuilder setWelcomeMessage(String welcomeMessage) {
        this.welcomeMessage = welcomeMessage;
        return this;
    }

    public MainBuilder setWelcomeMessageColor(Color welcomeMessageColor) {
        this.welcomeMessageColor = welcomeMessageColor;
        return this;
    }

    public MainBuilder setBackgroundImage(ImageIcon backgroundImage) {
        this.backgroundImage = backgroundImage;
        return this;
    }

    public MainBuilder setSize(int width, int height) {
        this.width = width;
        this.height = height;
        return this;
    }

    public Main build() {
        return new Main(title, welcomeMessage, welcomeMessageColor, backgroundImage, width, height);
    }
}
